/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Date;
import java.sql.Time;

/**
 *
 * @author brenda
 */
public class M_Defensa {

    private int iddefensa;
    private Date fecha;
    private Time hora;
    private int aula;
    private String periodo;
    private int id_tesis;
    private int n_jurado1;
    private int n_jurado2;

    public M_Defensa() {
    }

    public M_Defensa(int iddefensa, Date fecha, Time hora, int aula, String periodo, int id_tesis, int n_jurado1, int n_jurado2) {
        this.iddefensa = iddefensa;
        this.fecha = fecha;
        this.hora = hora;
        this.aula = aula;
        this.periodo = periodo;
        this.id_tesis = id_tesis;
        this.n_jurado1 = n_jurado1;
        this.n_jurado2 = n_jurado2;
    }

    public int getIddefensa() {
        return iddefensa;
    }

    public void setIddefensa(int iddefensa) {
        this.iddefensa = iddefensa;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public int getAula() {
        return aula;
    }

    public void setAula(int aula) {
        this.aula = aula;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public int getId_tesis() {
        return id_tesis;
    }

    public void setId_tesis(int id_tesis) {
        this.id_tesis = id_tesis;
    }

    public int getN_jurado1() {
        return n_jurado1;
    }

    public void setN_jurado1(int n_jurado1) {
        this.n_jurado1 = n_jurado1;
    }

    public int getN_jurado2() {
        return n_jurado2;
    }

    public void setN_jurado2(int n_jurado2) {
        this.n_jurado2 = n_jurado2;
    }
    
       
}
